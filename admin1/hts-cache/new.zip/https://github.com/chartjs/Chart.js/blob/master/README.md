





<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
  <link rel="dns-prefetch" href="https://github.githubassets.com">
  <link rel="dns-prefetch" href="https://avatars0.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars1.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars2.githubusercontent.com">
  <link rel="dns-prefetch" href="https://avatars3.githubusercontent.com">
  <link rel="dns-prefetch" href="https://github-cloud.s3.amazonaws.com">
  <link rel="dns-prefetch" href="https://user-images.githubusercontent.com/">



  <link crossorigin="anonymous" media="all" integrity="sha512-lLo2nlsdl+bHLu6PGvC2j3wfP45RnK4wKQLiPnCDcuXfU38AiD+JCdMywnF3WbJC1jaxe3lAI6AM4uJuMFBLEw==" rel="stylesheet" href="https://github.githubassets.com/assets/frameworks-08fc49d3bd2694c870ea23d0906f3610.css" />
  <link crossorigin="anonymous" media="all" integrity="sha512-4uGK0ShNgzWQsGgymTkvfTGTzTPEWGJ3wDZY9XLuD+x2ZjFy96V/fQtjfSB4MpiZe6Ku4vHpO68TLZBmHd2u/g==" rel="stylesheet" href="https://github.githubassets.com/assets/github-70eb9e0a76b2f9f2f6f6806f031fcdfa.css" />
  
  
  <link crossorigin="anonymous" media="all" integrity="sha512-pRUIkQAzdqwh9okCkB8+vsbAzGV8+0PuBBxtu7NDiFvKmou5JvbWMkD7537JMiEtuXGJf98bmeN1ItoZ9/9EYw==" rel="stylesheet" href="https://github.githubassets.com/assets/site-1db8be7ffcb46f27cfd31a2813fb8aee.css" />
  
  

  <meta name="viewport" content="width=device-width">
  
  <title>Chart.js/README.md at master · chartjs/Chart.js · GitHub</title>
    <meta name="description" content="Simple HTML5 Charts using the &lt;canvas&gt; tag. Contribute to chartjs/Chart.js development by creating an account on GitHub.">
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">
  <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
  <meta property="fb:app_id" content="1401488693436528">

    
    <meta property="og:image" content="https://avatars3.githubusercontent.com/u/10342521?s=400&amp;v=4" /><meta property="og:site_name" content="GitHub" /><meta property="og:type" content="object" /><meta property="og:title" content="chartjs/Chart.js" /><meta property="og:url" content="https://github.com/chartjs/Chart.js" /><meta property="og:description" content="Simple HTML5 Charts using the &lt;canvas&gt; tag. Contribute to chartjs/Chart.js development by creating an account on GitHub." />

  <link rel="assets" href="https://github.githubassets.com/">
  
  <meta name="pjax-timeout" content="1000">
  
  <meta name="request-id" content="BC27:7C28:19D7C20:345F76E:5C1CCE42" data-pjax-transient>


  

  <meta name="selected-link" value="repo_source" data-pjax-transient>

      <meta name="google-site-verification" content="KT5gs8h0wvaagLKAVWq8bbeNwnZZK1r1XQysX3xurLU">
    <meta name="google-site-verification" content="ZzhVyEFwb7w3e0-uOTltm8Jsck2F5StVihD0exw2fsA">
    <meta name="google-site-verification" content="GXs5KoUUkNCoaAZn7wPN-t01Pywp9M3sEjnt_3_ZWPc">

  <meta name="octolytics-host" content="collector.githubapp.com" /><meta name="octolytics-app-id" content="github" /><meta name="octolytics-event-url" content="https://collector.githubapp.com/github-external/browser_event" /><meta name="octolytics-dimension-request_id" content="BC27:7C28:19D7C20:345F76E:5C1CCE42" /><meta name="octolytics-dimension-region_edge" content="iad" /><meta name="octolytics-dimension-region_render" content="iad" />
<meta name="analytics-location" content="/&lt;user-name&gt;/&lt;repo-name&gt;/blob/show" data-pjax-transient="true" />



    <meta name="google-analytics" content="UA-3769691-2">


<meta class="js-ga-set" name="dimension1" content="Logged Out">



  

      <meta name="hostname" content="github.com">
    <meta name="user-login" content="">

      <meta name="expected-hostname" content="github.com">
    <meta name="js-proxy-site-detection-payload" content="OTYwMjQ3Y2I4ZWI3YjZkY2IyYzQwNTBiNDRjYTJlNjA1NzU4YWQ4NTZiNzI5MmY1YTk1OTNmZDZiNTU0OGQwY3x7InJlbW90ZV9hZGRyZXNzIjoiMTE1Ljk2LjE0LjQ4IiwicmVxdWVzdF9pZCI6IkJDMjc6N0MyODoxOUQ3QzIwOjM0NUY3NkU6NUMxQ0NFNDIiLCJ0aW1lc3RhbXAiOjE1NDUzOTE2ODMsImhvc3QiOiJnaXRodWIuY29tIn0=">

    <meta name="enabled-features" content="DASHBOARD_V2_LAYOUT_OPT_IN,EXPLORE_DISCOVER_REPOSITORIES,UNIVERSE_BANNER,MARKETPLACE_PLAN_RESTRICTION_EDITOR">

  <meta name="html-safe-nonce" content="8d255e27b84696f98614bfaf783c7df976306e55">

  <meta http-equiv="x-pjax-version" content="d23812c8cbe942c4228238f1f842a13b">
  

      <link href="https://github.com/chartjs/Chart.js/commits/master.atom" rel="alternate" title="Recent Commits to Chart.js:master" type="application/atom+xml">

  <meta name="go-import" content="github.com/chartjs/Chart.js git https://github.com/chartjs/Chart.js.git">

  <meta name="octolytics-dimension-user_id" content="10342521" /><meta name="octolytics-dimension-user_login" content="chartjs" /><meta name="octolytics-dimension-repository_id" content="8843683" /><meta name="octolytics-dimension-repository_nwo" content="chartjs/Chart.js" /><meta name="octolytics-dimension-repository_public" content="true" /><meta name="octolytics-dimension-repository_is_fork" content="false" /><meta name="octolytics-dimension-repository_network_root_id" content="8843683" /><meta name="octolytics-dimension-repository_network_root_nwo" content="chartjs/Chart.js" /><meta name="octolytics-dimension-repository_explore_github_marketplace_ci_cta_shown" content="false" />


    <link rel="canonical" href="https://github.com/chartjs/Chart.js/blob/master/README.md" data-pjax-transient>


  <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">

  <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">

  <link rel="mask-icon" href="https://github.githubassets.com/pinned-octocat.svg" color="#000000">
  <link rel="icon" type="image/x-icon" class="js-site-favicon" href="https://github.githubassets.com/favicon.ico">

<meta name="theme-color" content="#1e2327">



  <link rel="manifest" href="/manifest.json" crossOrigin="use-credentials">

  </head>

  <body class="logged-out env-production page-blob">
    

  <div class="position-relative js-header-wrapper ">
    <a href="#start-of-content" tabindex="1" class="px-2 py-4 bg-blue text-white show-on-focus js-skip-to-content">Skip to content</a>
    <div id="js-pjax-loader-bar" class="pjax-loader-bar"><div class="progress"></div></div>

    
    
    


        
<header class="Header header-logged-out  position-relative f4 py-3" role="banner">
  <div class="container-lg d-flex px-3">
    <div class="d-flex flex-justify-between flex-items-center">
        <a class="mr-4" href="https://github.com/" aria-label="Homepage" data-ga-click="(Logged out) Header, go to homepage, icon:logo-wordmark; experiment:site_header_dropdowns; group:dropdowns">
          <svg height="32" class="octicon octicon-mark-github text-white" viewBox="0 0 16 16" version="1.1" width="32" aria-hidden="true"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>
        </a>
    </div>

    <div class="HeaderMenu HeaderMenu--logged-out d-flex flex-justify-between flex-items-center flex-auto">
      <div class="d-none">
        <button class="btn-link js-details-target" type="button" aria-label="Toggle navigation" aria-expanded="false">
          <svg height="24" class="octicon octicon-x text-gray" viewBox="0 0 12 16" version="1.1" width="18" aria-hidden="true"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48L7.48 8z"/></svg>
        </button>
      </div>

        <nav class="mt-0" aria-label="Global">
          <ul class="d-flex list-style-none">
              <li class=" mr-3 mr-lg-3 edge-item-fix position-relative flex-wrap flex-justify-between d-flex flex-items-center ">
                <details class="HeaderMenu-details details-overlay details-reset width-full">
                  <summary class="HeaderMenu-summary HeaderMenu-link px-0 py-3 border-0 no-wrap  d-inline-block">
                    Why GitHub?
                    <svg x="0px" y="0px" viewBox="0 0 14 8" xml:space="preserve" fill="none" class="icon-chevon-down-mktg position-relative">
                      <path d="M1,1l6.2,6L13,1"></path>
                    </svg>
                  </summary>
                  <div class="dropdown-menu flex-auto rounded-1 bg-white px-0 mt-0  p-4 left-n4 position-absolute">
                    <a href="/features" class="py-2 lh-condensed-ultra d-block link-gray-dark no-underline h5 Bump-link--hover" data-ga-click="(Logged out) Header, go to Features">Features <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a>
                    <ul class="list-style-none f5 pb-3">
                      <li class="edge-item-fix"><a href="/features/code-review/" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Code review">Code review</a></li>
                      <li class="edge-item-fix"><a href="/features/project-management/" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Project management">Project management</a></li>
                      <li class="edge-item-fix"><a href="/features/integrations" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Integrations">Integrations</a></li>
                      <li class="edge-item-fix"><a href="/features#team-management" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Team management">Team management</a></li>
                      <li class="edge-item-fix"><a href="/features#social-coding" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Social coding">Social coding</a></li>
                      <li class="edge-item-fix"><a href="/features#documentation" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Documentation">Documentation</a></li>
                      <li class="edge-item-fix"><a href="/features#code-hosting" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Code hosting">Code hosting</a></li>
                    </ul>

                    <ul class="list-style-none mb-0 border-lg-top pt-lg-3">
                      <li class="edge-item-fix"><a href="/case-studies" class="py-2 lh-condensed-ultra d-block no-underline link-gray-dark no-underline h5 Bump-link--hover" data-ga-click="(Logged out) Header, go to Case studies">Case Studies <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a></li>
                      <li class="edge-item-fix"><a href="/security" class="py-2 lh-condensed-ultra d-block no-underline link-gray-dark no-underline h5 Bump-link--hover" data-ga-click="(Logged out) Header, go to Security">Security <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a></li>
                    </ul>
                  </div>
                </details>
              </li>
              <li class=" mr-3 mr-lg-3">
                <a href="/business" class="HeaderMenu-link no-underline py-3 d-block d-lg-inline-block" data-ga-click="(Logged out) Header, go to Business">Business</a>
              </li>

              <li class=" mr-3 mr-lg-3 edge-item-fix position-relative flex-wrap flex-justify-between d-flex flex-items-center ">
                <details class="HeaderMenu-details details-overlay details-reset width-full">
                  <summary class="HeaderMenu-summary HeaderMenu-link px-0 py-3 border-0 no-wrap  d-inline-block">
                    Explore
                    <svg x="0px" y="0px" viewBox="0 0 14 8" xml:space="preserve" fill="none" class="icon-chevon-down-mktg position-relative">
                      <path d="M1,1l6.2,6L13,1"></path>
                    </svg>
                  </summary>

                  <div class="dropdown-menu flex-auto rounded-1 bg-white px-0 pt-2 pb-0 mt-0  p-4 left-n4 position-absolute">
                    <ul class="list-style-none mb-3">
                      <li class="edge-item-fix"><a href="/explore" class="py-2 lh-condensed-ultra d-block link-gray-dark no-underline h5 Bump-link--hover" data-ga-click="(Logged out) Header, go to Features">Explore GitHub <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a></li>
                    </ul>

                    <h4 class="text-gray-light text-normal text-mono f5 mb-2  border-top pt-3">Learn &amp; contribute</h4>
                    <ul class="list-style-none mb-3">
                      <li class="edge-item-fix"><a href="/topics" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Topics">Topics</a></li>
                      <li class="edge-item-fix"><a href="/collections" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Collections">Collections</a></li>
                      <li class="edge-item-fix"><a href="/trending" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Trending">Trending</a></li>
                      <li class="edge-item-fix"><a href="https://lab.github.com/" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Learning lab">Learning Lab</a></li>
                      <li class="edge-item-fix"><a href="https://opensource.guide" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Open source guides">Open source guides</a></li>
                    </ul>

                    <h4 class="text-gray-light text-normal text-mono f5 mb-2  border-top pt-3">Connect with others</h4>
                    <ul class="list-style-none mb-0">
                      <li class="edge-item-fix"><a href="/events" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Events">Events</a></li>
                      <li class="edge-item-fix"><a href="https://github.community" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Community forum">Community forum</a></li>
                      <li class="edge-item-fix"><a href="https://education.github.com" class="py-2 pb-0 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to GitHub Education">GitHub Education</a></li>
                    </ul>
                  </div>
                </details>
              </li>

              <li class=" mr-3 mr-lg-3">
                <a href="/marketplace" class="HeaderMenu-link no-underline py-3 d-block d-lg-inline-block" data-ga-click="(Logged out) Header, go to Marketplace">Marketplace</a>
              </li>

              <li class=" mr-3 mr-lg-3 edge-item-fix position-relative flex-wrap flex-justify-between d-flex flex-items-center ">
                <details class="HeaderMenu-details details-overlay details-reset width-full">
                  <summary class="HeaderMenu-summary HeaderMenu-link px-0 py-3 border-0 no-wrap  d-inline-block">
                    Pricing
                    <svg x="0px" y="0px" viewBox="0 0 14 8" xml:space="preserve" fill="none" class="icon-chevon-down-mktg position-relative">
                       <path d="M1,1l6.2,6L13,1"></path>
                    </svg>
                  </summary>

                  <div class="dropdown-menu flex-auto rounded-1 bg-white px-0 pt-2 pb-4 mt-0  p-4 left-n4 position-absolute">
                    <a href="/pricing" class="pb-2 lh-condensed-ultra d-block link-gray-dark no-underline h5 Bump-link--hover" data-ga-click="(Logged out) Header, go to Pricing">Plans <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a>

                    <ul class="list-style-none mb-3">
                      <li class="edge-item-fix"><a href="/pricing#feature-comparison" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Compare features">Compare plans</a></li>
                      <li class="edge-item-fix"><a href="https://enterprise.github.com/contact" class="py-2 lh-condensed-ultra d-block link-gray no-underline f5" data-ga-click="(Logged out) Header, go to Compare features">Contact Sales</a></li>
                    </ul>

                    <ul class="list-style-none mb-0  border-top pt-3">
                      <li class="edge-item-fix"><a href="/nonprofit" class="py-2 lh-condensed-ultra d-block no-underline link-gray-dark no-underline h5 Bump-link--hover" data-ga-click="(Logged out) Header, go to Nonprofits">Nonprofit <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a></li>
                      <li class="edge-item-fix"><a href="https://education.github.com/discount_requests/new" class="py-2 pb-0 lh-condensed-ultra d-block no-underline link-gray-dark no-underline h5 Bump-link--hover"  data-ga-click="(Logged out) Header, go to Education">Education <span class="Bump-link-symbol float-right text-normal text-gray-light">&rarr;</span></a></li>
                    </ul>
                  </div>
                </details>
              </li>
          </ul>
        </nav>

      <div class="d-flex flex-items-center px-0 text-center text-left">
          <div class="d-lg-flex mr-3">
            <div class="header-search scoped-search site-scoped-search js-site-search position-relative js-jump-to"
  role="combobox"
  aria-owns="jump-to-results"
  aria-label="Search or jump to"
  aria-haspopup="listbox"
  aria-expanded="false"
>
  <div class="position-relative">
    <!-- '"` --><!-- </textarea></xmp> --></option></form><form class="js-site-search-form" data-scope-type="Repository" data-scope-id="8843683" data-scoped-search-url="/chartjs/Chart.js/search" data-unscoped-search-url="/search" action="/chartjs/Chart.js/search" accept-charset="UTF-8" method="get"><input name="utf8" type="hidden" value="&#x2713;" />
      <label class="form-control header-search-wrapper header-search-wrapper-jump-to position-relative d-flex flex-justify-between flex-items-center js-chromeless-input-container">
        <input type="text"
          class="form-control header-search-input jump-to-field js-jump-to-field js-site-search-focus js-site-search-field is-clearable"
          data-hotkey="s,/"
          name="q"
          value=""
          placeholder="Search"
          data-unscoped-placeholder="Search GitHub"
          data-scoped-placeholder="Search"
          autocapitalize="off"
          aria-autocomplete="list"
          aria-controls="jump-to-results"
          aria-label="Search"
          data-jump-to-suggestions-path="/_graphql/GetSuggestedNavigationDestinations#csrf-token=M/rKlmycezIOYbwl0CEf7VxqwRz8Sv/XjIG6TpBtQmW+BCFVbOSqK8dvMYXF3t2EpsTuYYPbkR3Khxs1cgZueg=="
          spellcheck="false"
          autocomplete="off"
          >
          <input type="hidden" class="js-site-search-type-field" name="type" >
            <img src="https://github.githubassets.com/images/search-key-slash.svg" alt="" class="mr-2 header-search-key-slash">

            <div class="Box position-absolute overflow-hidden d-none jump-to-suggestions js-jump-to-suggestions-container">
              
<ul class="d-none js-jump-to-suggestions-template-container">
  

<li class="d-flex flex-justify-start flex-items-center p-0 f5 navigation-item js-navigation-item js-jump-to-suggestion" role="option">
  <a tabindex="-1" class="no-underline d-flex flex-auto flex-items-center jump-to-suggestions-path js-jump-to-suggestion-path js-navigation-open p-2" href="">
    <div class="jump-to-octicon js-jump-to-octicon flex-shrink-0 mr-2 text-center d-none">
      <svg height="16" width="16" class="octicon octicon-repo flex-shrink-0 js-jump-to-octicon-repo d-none" title="Repository" aria-label="Repository" viewBox="0 0 12 16" version="1.1" role="img"><path fill-rule="evenodd" d="M4 9H3V8h1v1zm0-3H3v1h1V6zm0-2H3v1h1V4zm0-2H3v1h1V2zm8-1v12c0 .55-.45 1-1 1H6v2l-1.5-1.5L3 16v-2H1c-.55 0-1-.45-1-1V1c0-.55.45-1 1-1h10c.55 0 1 .45 1 1zm-1 10H1v2h2v-1h3v1h5v-2zm0-10H2v9h9V1z"/></svg>
      <svg height="16" width="16" class="octicon octicon-project flex-shrink-0 js-jump-to-octicon-project d-none" title="Project" aria-label="Project" viewBox="0 0 15 16" version="1.1" role="img"><path fill-rule="evenodd" d="M10 12h3V2h-3v10zm-4-2h3V2H6v8zm-4 4h3V2H2v12zm-1 1h13V1H1v14zM14 0H1a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h13a1 1 0 0 0 1-1V1a1 1 0 0 0-1-1z"/></svg>
      <svg height="16" width="16" class="octicon octicon-search flex-shrink-0 js-jump-to-octicon-search d-none" title="Search" aria-label="Search" viewBox="0 0 16 16" version="1.1" role="img"><path fill-rule="evenodd" d="M15.7 13.3l-3.81-3.83A5.93 5.93 0 0 0 13 6c0-3.31-2.69-6-6-6S1 2.69 1 6s2.69 6 6 6c1.3 0 2.48-.41 3.47-1.11l3.83 3.81c.19.2.45.3.7.3.25 0 .52-.09.7-.3a.996.996 0 0 0 0-1.41v.01zM7 10.7c-2.59 0-4.7-2.11-4.7-4.7 0-2.59 2.11-4.7 4.7-4.7 2.59 0 4.7 2.11 4.7 4.7 0 2.59-2.11 4.7-4.7 4.7z"/></svg>
    </div>

    <img class="avatar mr-2 flex-shrink-0 js-jump-to-suggestion-avatar d-none" alt="" aria-label="Team" src="" width="28" height="28">

    <div class="jump-to-suggestion-name js-jump-to-suggestion-name flex-auto overflow-hidden text-left no-wrap css-truncate css-truncate-target">
    </div>

    <div class="border rounded-1 flex-shrink-0 bg-gray px-1 text-gray-light ml-1 f6 d-none js-jump-to-badge-search">
      <span class="js-jump-to-badge-search-text-default d-none" aria-label="in this repository">
        In this repository
      </span>
      <span class="js-jump-to-badge-search-text-global d-none" aria-label="in all of GitHub">
        All GitHub
      </span>
      <span aria-hidden="true" class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>

    <div aria-hidden="true" class="border rounded-1 flex-shrink-0 bg-gray px-1 text-gray-light ml-1 f6 d-none d-on-nav-focus js-jump-to-badge-jump">
      Jump to
      <span class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>
  </a>
</li>

</ul>

<ul class="d-none js-jump-to-no-results-template-container">
  <li class="d-flex flex-justify-center flex-items-center f5 d-none js-jump-to-suggestion p-2">
    <span class="text-gray">No suggested jump to results</span>
  </li>
</ul>

<ul id="jump-to-results" role="listbox" class="p-0 m-0 js-navigation-container jump-to-suggestions-results-container js-jump-to-suggestions-results-container">
  

<li class="d-flex flex-justify-start flex-items-center p-0 f5 navigation-item js-navigation-item js-jump-to-scoped-search d-none" role="option">
  <a tabindex="-1" class="no-underline d-flex flex-auto flex-items-center jump-to-suggestions-path js-jump-to-suggestion-path js-navigation-open p-2" href="">
    <div class="jump-to-octicon js-jump-to-octicon flex-shrink-0 mr-2 text-center d-none">
      <svg height="16" width="16" class="octicon octicon-repo flex-shrink-0 js-jump-to-octicon-repo d-none" title="Repository" aria-label="Repository" viewBox="0 0 12 16" version="1.1" role="img"><path fill-rule="evenodd" d="M4 9H3V8h1v1zm0-3H3v1h1V6zm0-2H3v1h1V4zm0-2H3v1h1V2zm8-1v12c0 .55-.45 1-1 1H6v2l-1.5-1.5L3 16v-2H1c-.55 0-1-.45-1-1V1c0-.55.45-1 1-1h10c.55 0 1 .45 1 1zm-1 10H1v2h2v-1h3v1h5v-2zm0-10H2v9h9V1z"/></svg>
      <svg height="16" width="16" class="octicon octicon-project flex-shrink-0 js-jump-to-octicon-project d-none" title="Project" aria-label="Project" viewBox="0 0 15 16" version="1.1" role="img"><path fill-rule="evenodd" d="M10 12h3V2h-3v10zm-4-2h3V2H6v8zm-4 4h3V2H2v12zm-1 1h13V1H1v14zM14 0H1a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h13a1 1 0 0 0 1-1V1a1 1 0 0 0-1-1z"/></svg>
      <svg height="16" width="16" class="octicon octicon-search flex-shrink-0 js-jump-to-octicon-search d-none" title="Search" aria-label="Search" viewBox="0 0 16 16" version="1.1" role="img"><path fill-rule="evenodd" d="M15.7 13.3l-3.81-3.83A5.93 5.93 0 0 0 13 6c0-3.31-2.69-6-6-6S1 2.69 1 6s2.69 6 6 6c1.3 0 2.48-.41 3.47-1.11l3.83 3.81c.19.2.45.3.7.3.25 0 .52-.09.7-.3a.996.996 0 0 0 0-1.41v.01zM7 10.7c-2.59 0-4.7-2.11-4.7-4.7 0-2.59 2.11-4.7 4.7-4.7 2.59 0 4.7 2.11 4.7 4.7 0 2.59-2.11 4.7-4.7 4.7z"/></svg>
    </div>

    <img class="avatar mr-2 flex-shrink-0 js-jump-to-suggestion-avatar d-none" alt="" aria-label="Team" src="" width="28" height="28">

    <div class="jump-to-suggestion-name js-jump-to-suggestion-name flex-auto overflow-hidden text-left no-wrap css-truncate css-truncate-target">
    </div>

    <div class="border rounded-1 flex-shrink-0 bg-gray px-1 text-gray-light ml-1 f6 d-none js-jump-to-badge-search">
      <span class="js-jump-to-badge-search-text-default d-none" aria-label="in this repository">
        In this repository
      </span>
      <span class="js-jump-to-badge-search-text-global d-none" aria-label="in all of GitHub">
        All GitHub
      </span>
      <span aria-hidden="true" class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>

    <div aria-hidden="true" class="border rounded-1 flex-shrink-0 bg-gray px-1 text-gray-light ml-1 f6 d-none d-on-nav-focus js-jump-to-badge-jump">
      Jump to
      <span class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>
  </a>
</li>

  

<li class="d-flex flex-justify-start flex-items-center p-0 f5 navigation-item js-navigation-item js-jump-to-global-search d-none" role="option">
  <a tabindex="-1" class="no-underline d-flex flex-auto flex-items-center jump-to-suggestions-path js-jump-to-suggestion-path js-navigation-open p-2" href="">
    <div class="jump-to-octicon js-jump-to-octicon flex-shrink-0 mr-2 text-center d-none">
      <svg height="16" width="16" class="octicon octicon-repo flex-shrink-0 js-jump-to-octicon-repo d-none" title="Repository" aria-label="Repository" viewBox="0 0 12 16" version="1.1" role="img"><path fill-rule="evenodd" d="M4 9H3V8h1v1zm0-3H3v1h1V6zm0-2H3v1h1V4zm0-2H3v1h1V2zm8-1v12c0 .55-.45 1-1 1H6v2l-1.5-1.5L3 16v-2H1c-.55 0-1-.45-1-1V1c0-.55.45-1 1-1h10c.55 0 1 .45 1 1zm-1 10H1v2h2v-1h3v1h5v-2zm0-10H2v9h9V1z"/></svg>
      <svg height="16" width="16" class="octicon octicon-project flex-shrink-0 js-jump-to-octicon-project d-none" title="Project" aria-label="Project" viewBox="0 0 15 16" version="1.1" role="img"><path fill-rule="evenodd" d="M10 12h3V2h-3v10zm-4-2h3V2H6v8zm-4 4h3V2H2v12zm-1 1h13V1H1v14zM14 0H1a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h13a1 1 0 0 0 1-1V1a1 1 0 0 0-1-1z"/></svg>
      <svg height="16" width="16" class="octicon octicon-search flex-shrink-0 js-jump-to-octicon-search d-none" title="Search" aria-label="Search" viewBox="0 0 16 16" version="1.1" role="img"><path fill-rule="evenodd" d="M15.7 13.3l-3.81-3.83A5.93 5.93 0 0 0 13 6c0-3.31-2.69-6-6-6S1 2.69 1 6s2.69 6 6 6c1.3 0 2.48-.41 3.47-1.11l3.83 3.81c.19.2.45.3.7.3.25 0 .52-.09.7-.3a.996.996 0 0 0 0-1.41v.01zM7 10.7c-2.59 0-4.7-2.11-4.7-4.7 0-2.59 2.11-4.7 4.7-4.7 2.59 0 4.7 2.11 4.7 4.7 0 2.59-2.11 4.7-4.7 4.7z"/></svg>
    </div>

    <img class="avatar mr-2 flex-shrink-0 js-jump-to-suggestion-avatar d-none" alt="" aria-label="Team" src="" width="28" height="28">

    <div class="jump-to-suggestion-name js-jump-to-suggestion-name flex-auto overflow-hidden text-left no-wrap css-truncate css-truncate-target">
    </div>

    <div class="border rounded-1 flex-shrink-0 bg-gray px-1 text-gray-light ml-1 f6 d-none js-jump-to-badge-search">
      <span class="js-jump-to-badge-search-text-default d-none" aria-label="in this repository">
        In this repository
      </span>
      <span class="js-jump-to-badge-search-text-global d-none" aria-label="in all of GitHub">
        All GitHub
      </span>
      <span aria-hidden="true" class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>

    <div aria-hidden="true" class="border rounded-1 flex-shrink-0 bg-gray px-1 text-gray-light ml-1 f6 d-none d-on-nav-focus js-jump-to-badge-jump">
      Jump to
      <span class="d-inline-block ml-1 v-align-middle">↵</span>
    </div>
  </a>
</li>


</ul>

            </div>
      </label>
</form>  </div>
</div>

          </div>

        <a class="HeaderMenu-link no-underline mr-3" href="/login?return_to=%2Fchartjs%2FChart.js%2Fblob%2Fmaster%2FREADME.md" data-ga-click="(Logged out) Header, clicked Sign in, text:sign-in">Sign&nbsp;in</a>
          <a class="HeaderMenu-link d-inline-block no-underline border border-gray-dark rounded-1 px-2 py-1" href="/join" data-ga-click="(Logged out) Header, clicked Sign up, text:sign-up">Sign&nbsp;up</a>
      </div>
    </div>
  </div>
</header>

  </div>

  <div id="start-of-content" class="show-on-focus"></div>

    <div id="js-flash-container">

</div>



  <div role="main" class="application-main " data-commit-hovercards-enabled>
        <div itemscope itemtype="http://schema.org/SoftwareSourceCode" class="">
    <div id="js-repo-pjax-container" data-pjax-container >
      


  


  



  <div class="pagehead repohead instapaper_ignore readability-menu experiment-repo-nav  ">
    <div class="repohead-details-container clearfix container">

      <ul class="pagehead-actions">
  <li>
      <a href="/login?return_to=%2Fchartjs%2FChart.js"
    class="btn btn-sm btn-with-count tooltipped tooltipped-s"
    aria-label="You must be signed in to watch a repository" rel="nofollow">
    <svg class="octicon octicon-eye v-align-text-bottom" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8.06 2C3 2 0 8 0 8s3 6 8.06 6C13 14 16 8 16 8s-3-6-7.94-6zM8 12c-2.2 0-4-1.78-4-4 0-2.2 1.8-4 4-4 2.22 0 4 1.8 4 4 0 2.22-1.78 4-4 4zm2-4c0 1.11-.89 2-2 2-1.11 0-2-.89-2-2 0-1.11.89-2 2-2 1.11 0 2 .89 2 2z"/></svg>
    Watch
  </a>
  <a class="social-count" href="/chartjs/Chart.js/watchers"
     aria-label="1477 users are watching this repository">
    1,477
  </a>

  </li>

  <li>
        <a href="/login?return_to=%2Fchartjs%2FChart.js"
      class="btn btn-sm btn-with-count tooltipped tooltipped-s"
      aria-label="You must be signed in to star a repository" rel="nofollow">
      <svg class="octicon octicon-star v-align-text-bottom" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M14 6l-4.9-.64L7 1 4.9 5.36 0 6l3.6 3.26L2.67 14 7 11.67 11.33 14l-.93-4.74L14 6z"/></svg>
      Star
    </a>

    <a class="social-count js-social-count" href="/chartjs/Chart.js/stargazers"
      aria-label="40943 users starred this repository">
      40,943
    </a>

  </li>

  <li>
      <a href="/login?return_to=%2Fchartjs%2FChart.js"
        class="btn btn-sm btn-with-count tooltipped tooltipped-s"
        aria-label="You must be signed in to fork a repository" rel="nofollow">
        <svg class="octicon octicon-repo-forked v-align-text-bottom" viewBox="0 0 10 16" version="1.1" width="10" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8 1a1.993 1.993 0 0 0-1 3.72V6L5 8 3 6V4.72A1.993 1.993 0 0 0 2 1a1.993 1.993 0 0 0-1 3.72V6.5l3 3v1.78A1.993 1.993 0 0 0 5 15a1.993 1.993 0 0 0 1-3.72V9.5l3-3V4.72A1.993 1.993 0 0 0 8 1zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3 10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zm3-10c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z"/></svg>
        Fork
      </a>

    <a href="/chartjs/Chart.js/network/members" class="social-count"
       aria-label="9242 users forked this repository">
      9,242
    </a>
  </li>
</ul>

      <h1 class="public ">
  <svg class="octicon octicon-repo" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M4 9H3V8h1v1zm0-3H3v1h1V6zm0-2H3v1h1V4zm0-2H3v1h1V2zm8-1v12c0 .55-.45 1-1 1H6v2l-1.5-1.5L3 16v-2H1c-.55 0-1-.45-1-1V1c0-.55.45-1 1-1h10c.55 0 1 .45 1 1zm-1 10H1v2h2v-1h3v1h5v-2zm0-10H2v9h9V1z"/></svg>
  <span class="author" itemprop="author"><a class="url fn" rel="author" data-hovercard-type="organization" data-hovercard-url="/orgs/chartjs/hovercard" href="/chartjs">chartjs</a></span><!--
--><span class="path-divider">/</span><!--
--><strong itemprop="name"><a data-pjax="#js-repo-pjax-container" href="/chartjs/Chart.js">Chart.js</a></strong>

</h1>

    </div>
    
<nav class="reponav js-repo-nav js-sidenav-container-pjax container"
     itemscope
     itemtype="http://schema.org/BreadcrumbList"
    aria-label="Repository"
     data-pjax="#js-repo-pjax-container">

  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a class="js-selected-navigation-item selected reponav-item" itemprop="url" data-hotkey="g c" aria-current="page" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches repo_packages /chartjs/Chart.js" href="/chartjs/Chart.js">
      <svg class="octicon octicon-code" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M9.5 3L8 4.5 11.5 8 8 11.5 9.5 13 14 8 9.5 3zm-5 0L0 8l4.5 5L6 11.5 2.5 8 6 4.5 4.5 3z"/></svg>
      <span itemprop="name">Code</span>
      <meta itemprop="position" content="1">
</a>  </span>

    <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
      <a itemprop="url" data-hotkey="g i" class="js-selected-navigation-item reponav-item" data-selected-links="repo_issues repo_labels repo_milestones /chartjs/Chart.js/issues" href="/chartjs/Chart.js/issues">
        <svg class="octicon octicon-issue-opened" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7 2.3c3.14 0 5.7 2.56 5.7 5.7s-2.56 5.7-5.7 5.7A5.71 5.71 0 0 1 1.3 8c0-3.14 2.56-5.7 5.7-5.7zM7 1C3.14 1 0 4.14 0 8s3.14 7 7 7 7-3.14 7-7-3.14-7-7-7zm1 3H6v5h2V4zm0 6H6v2h2v-2z"/></svg>
        <span itemprop="name">Issues</span>
        <span class="Counter">431</span>
        <meta itemprop="position" content="2">
</a>    </span>

  <span itemscope itemtype="http://schema.org/ListItem" itemprop="itemListElement">
    <a data-hotkey="g p" itemprop="url" class="js-selected-navigation-item reponav-item" data-selected-links="repo_pulls checks /chartjs/Chart.js/pulls" href="/chartjs/Chart.js/pulls">
      <svg class="octicon octicon-git-pull-request" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M11 11.28V5c-.03-.78-.34-1.47-.94-2.06C9.46 2.35 8.78 2.03 8 2H7V0L4 3l3 3V4h1c.27.02.48.11.69.31.21.2.3.42.31.69v6.28A1.993 1.993 0 0 0 10 15a1.993 1.993 0 0 0 1-3.72zm-1 2.92c-.66 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2zM4 3c0-1.11-.89-2-2-2a1.993 1.993 0 0 0-1 3.72v6.56A1.993 1.993 0 0 0 2 15a1.993 1.993 0 0 0 1-3.72V4.72c.59-.34 1-.98 1-1.72zm-.8 10c0 .66-.55 1.2-1.2 1.2-.65 0-1.2-.55-1.2-1.2 0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2zM2 4.2C1.34 4.2.8 3.65.8 3c0-.65.55-1.2 1.2-1.2.65 0 1.2.55 1.2 1.2 0 .65-.55 1.2-1.2 1.2z"/></svg>
      <span itemprop="name">Pull requests</span>
      <span class="Counter">29</span>
      <meta itemprop="position" content="3">
</a>  </span>





    <a class="js-selected-navigation-item reponav-item" data-selected-links="repo_graphs repo_contributors dependency_graph pulse alerts security /chartjs/Chart.js/pulse" href="/chartjs/Chart.js/pulse">
      <svg class="octicon octicon-graph" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M16 14v1H0V0h1v14h15zM5 13H3V8h2v5zm4 0H7V3h2v10zm4 0h-2V6h2v7z"/></svg>
      Insights
</a>

</nav>


  </div>

<div class="container new-discussion-timeline experiment-repo-nav  ">
  <div class="repository-content ">

    
    



  
    <a class="d-none js-permalink-shortcut" data-hotkey="y" href="/chartjs/Chart.js/blob/4b6e53a6176ada6c8983fe8ccb4c0df713a069f9/README.md">Permalink</a>

    <!-- blob contrib key: blob_contributors:v21:73753173d13a1759faa12d0ebbb08656 -->

        <div class="signup-prompt-bg rounded-1">
      <div class="signup-prompt p-4 text-center mb-4 rounded-1">
        <div class="position-relative">
          <!-- '"` --><!-- </textarea></xmp> --></option></form><form action="/site/dismiss_signup_prompt" accept-charset="UTF-8" method="post"><input name="utf8" type="hidden" value="&#x2713;" /><input type="hidden" name="authenticity_token" value="Za3cbMpQBzXnt5Iz4dfs0Ti3mxZ7iZQzrkh5IoLdUH9agfbT/Qa49AlM2ZJQr3O6DTXW8Yjmc3uL1KtDJChbQg==" />
            <button type="submit" class="position-absolute top-0 right-0 btn-link link-gray" data-ga-click="(Logged out) Sign up prompt, clicked Dismiss, text:dismiss">
              Dismiss
            </button>
</form>          <h3 class="pt-2">Join GitHub today</h3>
          <p class="col-6 mx-auto">GitHub is home to over 28 million developers working together to host and review code, manage projects, and build software together.</p>
          <a class="btn btn-primary" href="/join?source=prompt-blob-show" data-ga-click="(Logged out) Sign up prompt, clicked Sign up, text:sign-up">Sign up</a>
        </div>
      </div>
    </div>


    <div class="file-navigation">
      
<div class="select-menu branch-select-menu js-menu-container js-select-menu float-left "
  >
  <button class="btn btn-sm select-menu-button js-menu-target css-truncate" data-hotkey="w"
    
    type="button" aria-label="Switch branches or tags" aria-expanded="false" aria-haspopup="true">
    <i>Branch:</i>
    <span class="js-select-button css-truncate-target">master</span>
  </button>

  <div class="select-menu-modal-holder js-menu-content js-navigation-container" data-pjax>
    <div class="select-menu-modal">
        
<div class="select-menu-header">
  <svg class="octicon octicon-x js-menu-close" role="img" aria-label="Close" viewBox="0 0 12 16" version="1.1" width="12" height="16"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48L7.48 8z"/></svg>
  <span class="select-menu-title">Switch branches/tags</span>
</div>

<tab-container>
<div class="select-menu-filters">
  <div class="select-menu-text-filter">
    <input type="text" aria-label="Filter branches/tags" id="context-commitish-filter-field" class="form-control js-filterable-field js-navigation-enable" placeholder="Filter branches/tags">
  </div>
  <div class="select-menu-tabs" role="tablist">
    <ul>
      <li class="select-menu-tab">
        <button type="button" class="select-menu-tab-nav" data-filter-placeholder="Filter branches/tags" role="tab" aria-selected="true">Branches</button>
      </li>
      <li class="select-menu-tab">
        <button type="button" class="select-menu-tab-nav" data-filter-placeholder="Find a tag…" role="tab">Tags</button>
      </li>
    </ul>
  </div>
</div>

<div class="select-menu-list" role="tabpanel">
  <div data-filterable-for="context-commitish-filter-field" data-filterable-type="substring">
      <a class="select-menu-item js-navigation-item js-navigation-open selected"
         href="/chartjs/Chart.js/blob/master/README.md"
         data-name="master"
         data-skip-pjax="true"
         rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target js-select-menu-filter-text">
          master
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
         href="/chartjs/Chart.js/blob/release/README.md"
         data-name="release"
         data-skip-pjax="true"
         rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target js-select-menu-filter-text">
          release
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
         href="/chartjs/Chart.js/blob/vertical-tick-alignment/README.md"
         data-name="vertical-tick-alignment"
         data-skip-pjax="true"
         rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target js-select-menu-filter-text">
          vertical-tick-alignment
        </span>
      </a>
  </div>

    <div class="select-menu-no-results">Nothing to show</div>
</div>

<div class="select-menu-list" role="tabpanel" hidden>
  <div data-filterable-for="context-commitish-filter-field" data-filterable-type="substring">
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.7.3/README.md"
        data-name="v2.7.3"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.7.3">
          v2.7.3
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.7.2/README.md"
        data-name="v2.7.2"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.7.2">
          v2.7.2
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.7.1/README.md"
        data-name="v2.7.1"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.7.1">
          v2.7.1
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.7.0/README.md"
        data-name="v2.7.0"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.7.0">
          v2.7.0
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.6.0/README.md"
        data-name="v2.6.0"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.6.0">
          v2.6.0
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.5.0/README.md"
        data-name="v2.5.0"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.5.0">
          v2.5.0
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.4.0/README.md"
        data-name="v2.4.0"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.4.0">
          v2.4.0
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.3.0/README.md"
        data-name="v2.3.0"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.3.0">
          v2.3.0
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.3.0-rc.1/README.md"
        data-name="v2.3.0-rc.1"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.3.0-rc.1">
          v2.3.0-rc.1
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.2.2/README.md"
        data-name="v2.2.2"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.2.2">
          v2.2.2
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.2.1/README.md"
        data-name="v2.2.1"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.2.1">
          v2.2.1
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.2.0/README.md"
        data-name="v2.2.0"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.2.0">
          v2.2.0
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.2.0-rc.2/README.md"
        data-name="v2.2.0-rc.2"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.2.0-rc.2">
          v2.2.0-rc.2
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.2.0-rc.1/README.md"
        data-name="v2.2.0-rc.1"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.2.0-rc.1">
          v2.2.0-rc.1
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.1.6/README.md"
        data-name="v2.1.6"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.1.6">
          v2.1.6
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.1.5/README.md"
        data-name="v2.1.5"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.1.5">
          v2.1.5
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.1.4/README.md"
        data-name="v2.1.4"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.1.4">
          v2.1.4
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.1.3/README.md"
        data-name="v2.1.3"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.1.3">
          v2.1.3
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.1.2/README.md"
        data-name="v2.1.2"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.1.2">
          v2.1.2
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.1.1/README.md"
        data-name="v2.1.1"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.1.1">
          v2.1.1
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.0.1/README.md"
        data-name="v2.0.1"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.0.1">
          v2.0.1
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.0.0/README.md"
        data-name="v2.0.0"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.0.0">
          v2.0.0
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v2.0-alpha/README.md"
        data-name="v2.0-alpha"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v2.0-alpha">
          v2.0-alpha
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v1.1.1/README.md"
        data-name="v1.1.1"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v1.1.1">
          v1.1.1
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v1.1.0/README.md"
        data-name="v1.1.0"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v1.1.0">
          v1.1.0
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v1.0.2/README.md"
        data-name="v1.0.2"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v1.0.2">
          v1.0.2
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v1.0.1/README.md"
        data-name="v1.0.1"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v1.0.1">
          v1.0.1
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v1.0.1-beta.4/README.md"
        data-name="v1.0.1-beta.4"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v1.0.1-beta.4">
          v1.0.1-beta.4
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v1.0.1-beta.3/README.md"
        data-name="v1.0.1-beta.3"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v1.0.1-beta.3">
          v1.0.1-beta.3
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v1.0.1-beta.2/README.md"
        data-name="v1.0.1-beta.2"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v1.0.1-beta.2">
          v1.0.1-beta.2
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v1.0.1-beta/README.md"
        data-name="v1.0.1-beta"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v1.0.1-beta">
          v1.0.1-beta
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v1.0.0-beta/README.md"
        data-name="v1.0.0-beta"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v1.0.0-beta">
          v1.0.0-beta
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/v0.2.0/README.md"
        data-name="v0.2.0"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="v0.2.0">
          v0.2.0
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/2.1.0/README.md"
        data-name="2.1.0"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="2.1.0">
          2.1.0
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/2.0.2/README.md"
        data-name="2.0.2"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="2.0.2">
          2.0.2
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/2.0.0-beta2/README.md"
        data-name="2.0.0-beta2"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="2.0.0-beta2">
          2.0.0-beta2
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/2.0.0-beta1/README.md"
        data-name="2.0.0-beta1"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="2.0.0-beta1">
          2.0.0-beta1
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/2.0.0-beta/README.md"
        data-name="2.0.0-beta"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="2.0.0-beta">
          2.0.0-beta
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/2.0.0-alpha4/README.md"
        data-name="2.0.0-alpha4"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="2.0.0-alpha4">
          2.0.0-alpha4
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/2.0.0-alpha3/README.md"
        data-name="2.0.0-alpha3"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="2.0.0-alpha3">
          2.0.0-alpha3
        </span>
      </a>
      <a class="select-menu-item js-navigation-item js-navigation-open "
        href="/chartjs/Chart.js/blob/2.0.0-alpha2/README.md"
        data-name="2.0.0-alpha2"
        data-skip-pjax="true"
        rel="nofollow">
        <svg class="octicon octicon-check select-menu-item-icon" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M12 5l-8 8-4-4 1.5-1.5L4 10l6.5-6.5L12 5z"/></svg>
        <span class="select-menu-item-text css-truncate-target" title="2.0.0-alpha2">
          2.0.0-alpha2
        </span>
      </a>
  </div>

  <div class="select-menu-no-results">Nothing to show</div>
</div>
</tab-container>


    </div>
  </div>
</div>

      <div class="BtnGroup float-right">
        <a href="/chartjs/Chart.js/find/master"
              class="js-pjax-capture-input btn btn-sm BtnGroup-item"
              data-pjax
              data-hotkey="t">
          Find file
        </a>
        <clipboard-copy for="blob-path" class="btn btn-sm BtnGroup-item">
          Copy path
        </clipboard-copy>
      </div>
      <div id="blob-path" class="breadcrumb">
        <span class="repo-root js-repo-root"><span class="js-path-segment"><a data-pjax="true" href="/chartjs/Chart.js"><span>Chart.js</span></a></span></span><span class="separator">/</span><strong class="final-path">README.md</strong>
      </div>
    </div>


    
  <div class="commit-tease">
      <span class="float-right">
        <a class="commit-tease-sha" href="/chartjs/Chart.js/commit/b3d3df4239c37fa5d55c7b0ea08b71492f8e61ba" data-pjax>
          b3d3df4
        </a>
        <relative-time datetime="2018-12-16T10:58:29Z">Dec 16, 2018</relative-time>
      </span>
      <div>
        <a rel="contributor" data-skip-pjax="true" data-hovercard-type="user" data-hovercard-url="/hovercards?user_id=3874900" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/simonbrunel"><img class="avatar" src="https://avatars2.githubusercontent.com/u/3874900?s=40&amp;v=4" width="20" height="20" alt="@simonbrunel" /></a>
        <a class="user-mention" rel="contributor" data-hovercard-type="user" data-hovercard-url="/hovercards?user_id=3874900" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/simonbrunel">simonbrunel</a>
          <a data-pjax="true" title="Use HTTPS instead of HTTP for URLs supporting it" class="message" href="/chartjs/Chart.js/commit/b3d3df4239c37fa5d55c7b0ea08b71492f8e61ba">Use HTTPS instead of HTTP for URLs supporting it</a>
      </div>

    <div class="commit-tease-contributors">
      
<details class="details-reset details-overlay details-overlay-dark lh-default text-gray-dark float-left mr-2" id="blob_contributors_box">
  <summary class="btn-link" aria-haspopup="dialog"  >
    
    <span><strong>13</strong> contributors</span>
  </summary>
  <details-dialog class="Box Box--overlay d-flex flex-column anim-fade-in fast " aria-label="Users who have contributed to this file">
    <div class="Box-header">
      <button class="Box-btn-octicon btn-octicon float-right" type="button" aria-label="Close dialog" data-close-dialog>
        <svg class="octicon octicon-x" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48L7.48 8z"/></svg>
      </button>
      <h3 class="Box-title">Users who have contributed to this file</h3>
    </div>
    
        <ul class="list-style-none overflow-auto">
            <li class="Box-row">
              <a class="link-gray-dark no-underline" href="/etimberg">
                <img class="avatar mr-2" alt="" src="https://avatars0.githubusercontent.com/u/6757853?s=40&amp;v=4" width="20" height="20" />
                etimberg
</a>            </li>
            <li class="Box-row">
              <a class="link-gray-dark no-underline" href="/simonbrunel">
                <img class="avatar mr-2" alt="" src="https://avatars2.githubusercontent.com/u/3874900?s=40&amp;v=4" width="20" height="20" />
                simonbrunel
</a>            </li>
            <li class="Box-row">
              <a class="link-gray-dark no-underline" href="/nnnick">
                <img class="avatar mr-2" alt="" src="https://avatars2.githubusercontent.com/u/1458051?s=40&amp;v=4" width="20" height="20" />
                nnnick
</a>            </li>
            <li class="Box-row">
              <a class="link-gray-dark no-underline" href="/panzarino">
                <img class="avatar mr-2" alt="" src="https://avatars2.githubusercontent.com/u/7033952?s=40&amp;v=4" width="20" height="20" />
                panzarino
</a>            </li>
            <li class="Box-row">
              <a class="link-gray-dark no-underline" href="/fulldecent">
                <img class="avatar mr-2" alt="" src="https://avatars2.githubusercontent.com/u/382183?s=40&amp;v=4" width="20" height="20" />
                fulldecent
</a>            </li>
            <li class="Box-row">
              <a class="link-gray-dark no-underline" href="/tannerlinsley">
                <img class="avatar mr-2" alt="" src="https://avatars0.githubusercontent.com/u/5580297?s=40&amp;v=4" width="20" height="20" />
                tannerlinsley
</a>            </li>
            <li class="Box-row">
              <a class="link-gray-dark no-underline" href="/jakesyl">
                <img class="avatar mr-2" alt="" src="https://avatars2.githubusercontent.com/u/6392429?s=40&amp;v=4" width="20" height="20" />
                jakesyl
</a>            </li>
            <li class="Box-row">
              <a class="link-gray-dark no-underline" href="/benmccann">
                <img class="avatar mr-2" alt="" src="https://avatars2.githubusercontent.com/u/322311?s=40&amp;v=4" width="20" height="20" />
                benmccann
</a>            </li>
            <li class="Box-row">
              <a class="link-gray-dark no-underline" href="/wla80">
                <img class="avatar mr-2" alt="" src="https://avatars0.githubusercontent.com/u/13490408?s=40&amp;v=4" width="20" height="20" />
                wla80
</a>            </li>
            <li class="Box-row">
              <a class="link-gray-dark no-underline" href="/gdvalderrama">
                <img class="avatar mr-2" alt="" src="https://avatars2.githubusercontent.com/u/7897337?s=40&amp;v=4" width="20" height="20" />
                gdvalderrama
</a>            </li>
            <li class="Box-row">
              <a class="link-gray-dark no-underline" href="/dkm">
                <img class="avatar mr-2" alt="" src="https://avatars0.githubusercontent.com/u/87603?s=40&amp;v=4" width="20" height="20" />
                dkm
</a>            </li>
            <li class="Box-row">
              <a class="link-gray-dark no-underline" href="/derekperkins">
                <img class="avatar mr-2" alt="" src="https://avatars2.githubusercontent.com/u/3588778?s=40&amp;v=4" width="20" height="20" />
                derekperkins
</a>            </li>
            <li class="Box-row">
              <a class="link-gray-dark no-underline" href="/alex-paterson">
                <img class="avatar mr-2" alt="" src="https://avatars0.githubusercontent.com/u/2718314?s=40&amp;v=4" width="20" height="20" />
                alex-paterson
</a>            </li>
        </ul>

  </details-dialog>
</details>
          <a class="avatar-link" data-hovercard-type="user" data-hovercard-url="/hovercards?user_id=6757853" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/chartjs/Chart.js/commits/master/README.md?author=etimberg">
      <img class="avatar" src="https://avatars0.githubusercontent.com/u/6757853?s=40&amp;v=4" width="20" height="20" alt="@etimberg" /> 
</a>    <a class="avatar-link" data-hovercard-type="user" data-hovercard-url="/hovercards?user_id=3874900" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/chartjs/Chart.js/commits/master/README.md?author=simonbrunel">
      <img class="avatar" src="https://avatars2.githubusercontent.com/u/3874900?s=40&amp;v=4" width="20" height="20" alt="@simonbrunel" /> 
</a>    <a class="avatar-link" data-hovercard-type="user" data-hovercard-url="/hovercards?user_id=1458051" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/chartjs/Chart.js/commits/master/README.md?author=nnnick">
      <img class="avatar" src="https://avatars2.githubusercontent.com/u/1458051?s=40&amp;v=4" width="20" height="20" alt="@nnnick" /> 
</a>    <a class="avatar-link" data-hovercard-type="user" data-hovercard-url="/hovercards?user_id=7033952" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/chartjs/Chart.js/commits/master/README.md?author=panzarino">
      <img class="avatar" src="https://avatars2.githubusercontent.com/u/7033952?s=40&amp;v=4" width="20" height="20" alt="@panzarino" /> 
</a>    <a class="avatar-link" data-hovercard-type="user" data-hovercard-url="/hovercards?user_id=382183" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/chartjs/Chart.js/commits/master/README.md?author=fulldecent">
      <img class="avatar" src="https://avatars2.githubusercontent.com/u/382183?s=40&amp;v=4" width="20" height="20" alt="@fulldecent" /> 
</a>    <a class="avatar-link" data-hovercard-type="user" data-hovercard-url="/hovercards?user_id=5580297" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/chartjs/Chart.js/commits/master/README.md?author=tannerlinsley">
      <img class="avatar" src="https://avatars0.githubusercontent.com/u/5580297?s=40&amp;v=4" width="20" height="20" alt="@tannerlinsley" /> 
</a>    <a class="avatar-link" data-hovercard-type="user" data-hovercard-url="/hovercards?user_id=6392429" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/chartjs/Chart.js/commits/master/README.md?author=jakesyl">
      <img class="avatar" src="https://avatars2.githubusercontent.com/u/6392429?s=40&amp;v=4" width="20" height="20" alt="@jakesyl" /> 
</a>    <a class="avatar-link" data-hovercard-type="user" data-hovercard-url="/hovercards?user_id=322311" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/chartjs/Chart.js/commits/master/README.md?author=benmccann">
      <img class="avatar" src="https://avatars2.githubusercontent.com/u/322311?s=40&amp;v=4" width="20" height="20" alt="@benmccann" /> 
</a>    <a class="avatar-link" data-hovercard-type="user" data-hovercard-url="/hovercards?user_id=13490408" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/chartjs/Chart.js/commits/master/README.md?author=wla80">
      <img class="avatar" src="https://avatars0.githubusercontent.com/u/13490408?s=40&amp;v=4" width="20" height="20" alt="@wla80" /> 
</a>    <a class="avatar-link" data-hovercard-type="user" data-hovercard-url="/hovercards?user_id=7897337" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/chartjs/Chart.js/commits/master/README.md?author=gdvalderrama">
      <img class="avatar" src="https://avatars2.githubusercontent.com/u/7897337?s=40&amp;v=4" width="20" height="20" alt="@gdvalderrama" /> 
</a>    <a class="avatar-link" data-hovercard-type="user" data-hovercard-url="/hovercards?user_id=87603" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/chartjs/Chart.js/commits/master/README.md?author=dkm">
      <img class="avatar" src="https://avatars0.githubusercontent.com/u/87603?s=40&amp;v=4" width="20" height="20" alt="@dkm" /> 
</a>    <a class="avatar-link" data-hovercard-type="user" data-hovercard-url="/hovercards?user_id=3588778" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/chartjs/Chart.js/commits/master/README.md?author=derekperkins">
      <img class="avatar" src="https://avatars2.githubusercontent.com/u/3588778?s=40&amp;v=4" width="20" height="20" alt="@derekperkins" /> 
</a>    <a class="avatar-link" data-hovercard-type="user" data-hovercard-url="/hovercards?user_id=2718314" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/chartjs/Chart.js/commits/master/README.md?author=alex-paterson">
      <img class="avatar" src="https://avatars0.githubusercontent.com/u/2718314?s=40&amp;v=4" width="20" height="20" alt="@alex-paterson" /> 
</a>

    </div>
  </div>



    <div class="file ">
      
<div class="file-header">

  <div class="file-actions">


    <div class="BtnGroup">
      <a id="raw-url" class="btn btn-sm BtnGroup-item" href="/chartjs/Chart.js/raw/master/README.md">Raw</a>
        <a class="btn btn-sm js-update-url-with-hash BtnGroup-item" data-hotkey="b" href="/chartjs/Chart.js/blame/master/README.md">Blame</a>
      <a rel="nofollow" class="btn btn-sm BtnGroup-item" href="/chartjs/Chart.js/commits/master/README.md">History</a>
    </div>


        <button type="button" class="btn-octicon disabled tooltipped tooltipped-nw"
          aria-label="You must be signed in to make or propose changes">
          <svg class="octicon octicon-pencil" viewBox="0 0 14 16" version="1.1" width="14" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M0 12v3h3l8-8-3-3-8 8zm3 2H1v-2h1v1h1v1zm10.3-9.3L12 6 9 3l1.3-1.3a.996.996 0 0 1 1.41 0l1.59 1.59c.39.39.39 1.02 0 1.41z"/></svg>
        </button>
        <button type="button" class="btn-octicon btn-octicon-danger disabled tooltipped tooltipped-nw"
          aria-label="You must be signed in to make or propose changes">
          <svg class="octicon octicon-trashcan" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M11 2H9c0-.55-.45-1-1-1H5c-.55 0-1 .45-1 1H2c-.55 0-1 .45-1 1v1c0 .55.45 1 1 1v9c0 .55.45 1 1 1h7c.55 0 1-.45 1-1V5c.55 0 1-.45 1-1V3c0-.55-.45-1-1-1zm-1 12H3V5h1v8h1V5h1v8h1V5h1v8h1V5h1v9zm1-10H2V3h9v1z"/></svg>
        </button>
  </div>

  <div class="file-info">
      58 lines (36 sloc)
      <span class="file-info-divider"></span>
    3.18 KB
  </div>
</div>

      
  <div id="readme" class="readme blob instapaper_body js-code-block-container">
    <article class="markdown-body entry-content" itemprop="text"><h1><a id="user-content-chartjs" class="anchor" aria-hidden="true" href="#chartjs"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"></path></svg></a>Chart.js</h1>
<p><a href="https://travis-ci.org/chartjs/Chart.js" rel="nofollow"><img src="https://camo.githubusercontent.com/6f25bc9afbd8ef68fb2e04dd19d2a78f2d296758/68747470733a2f2f696d672e736869656c64732e696f2f7472617669732f63686172746a732f43686172742e6a732e7376673f7374796c653d666c61742d737175617265266d61784167653d3630" alt="travis" data-canonical-src="https://img.shields.io/travis/chartjs/Chart.js.svg?style=flat-square&amp;maxAge=60" style="max-width:100%;"></a> <a href="https://coveralls.io/github/chartjs/Chart.js?branch=master" rel="nofollow"><img src="https://camo.githubusercontent.com/0d8e5c03d3876e33fbd60cb11ae30174889e8903/68747470733a2f2f696d672e736869656c64732e696f2f636f766572616c6c732f63686172746a732f43686172742e6a732e7376673f7374796c653d666c61742d737175617265266d61784167653d363030" alt="coveralls" data-canonical-src="https://img.shields.io/coveralls/chartjs/Chart.js.svg?style=flat-square&amp;maxAge=600" style="max-width:100%;"></a> <a href="https://codeclimate.com/github/chartjs/Chart.js" rel="nofollow"><img src="https://camo.githubusercontent.com/b9e2e650cd30611b007fe3383c19d32e64664826/68747470733a2f2f696d672e736869656c64732e696f2f636f6465636c696d6174652f6d61696e7461696e6162696c6974792f63686172746a732f43686172742e6a732e7376673f7374796c653d666c61742d737175617265266d61784167653d363030" alt="codeclimate" data-canonical-src="https://img.shields.io/codeclimate/maintainability/chartjs/Chart.js.svg?style=flat-square&amp;maxAge=600" style="max-width:100%;"></a> <a href="https://chartjs-slack.herokuapp.com/" rel="nofollow"><img src="https://camo.githubusercontent.com/a81c65de05aeea38ce0cad22620e5bd5a5e0d311/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f736c61636b2d63686172746a732d626c75652e7376673f7374796c653d666c61742d737175617265266d61784167653d33363030" alt="slack" data-canonical-src="https://img.shields.io/badge/slack-chartjs-blue.svg?style=flat-square&amp;maxAge=3600" style="max-width:100%;"></a></p>
<p><em>Simple HTML5 Charts using the canvas element</em> <a href="https://www.chartjs.org" rel="nofollow">chartjs.org</a></p>
<h2><a id="user-content-installation" class="anchor" aria-hidden="true" href="#installation"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"></path></svg></a>Installation</h2>
<p>You can download the latest version of Chart.js from the <a href="https://github.com/chartjs/Chart.js/releases/latest">GitHub releases</a> or use a <a href="https://cdnjs.com/libraries/Chart.js" rel="nofollow">Chart.js CDN</a>.</p>
<p>To install via npm:</p>
<div class="highlight highlight-source-shell"><pre>npm install chart.js --save</pre></div>
<p>To install via bower:</p>
<div class="highlight highlight-source-shell"><pre>bower install chart.js --save</pre></div>
<h3><a id="user-content-selecting-the-correct-build" class="anchor" aria-hidden="true" href="#selecting-the-correct-build"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"></path></svg></a>Selecting the Correct Build</h3>
<p>Chart.js provides two different builds for you to choose: <code>Stand-Alone Build</code>, <code>Bundled Build</code>.</p>
<h4><a id="user-content-stand-alone-build" class="anchor" aria-hidden="true" href="#stand-alone-build"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"></path></svg></a>Stand-Alone Build</h4>
<p>Files:</p>
<ul>
<li><code>dist/Chart.js</code></li>
<li><code>dist/Chart.min.js</code></li>
</ul>
<p>The stand-alone build includes Chart.js as well as the color parsing library. If this version is used, you are required to include <a href="https://momentjs.com/" rel="nofollow">Moment.js</a> before Chart.js for the functionality of the time axis.</p>
<h4><a id="user-content-bundled-build" class="anchor" aria-hidden="true" href="#bundled-build"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"></path></svg></a>Bundled Build</h4>
<p>Files:</p>
<ul>
<li><code>dist/Chart.bundle.js</code></li>
<li><code>dist/Chart.bundle.min.js</code></li>
</ul>
<p>The bundled build includes Moment.js in a single file. You should use this version if you require time axes and want to include a single file. You should not use this build if your application already included Moment.js. Otherwise, Moment.js will be included twice which results in increasing page load time and possible version compatibility issues. The Moment.js version in the bundled build is private to Chart.js so if you want to use Moment.js yourself, it's better to use Chart.js (non bundled) and import Moment.js manually.</p>
<h2><a id="user-content-documentation" class="anchor" aria-hidden="true" href="#documentation"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"></path></svg></a>Documentation</h2>
<p>You can find documentation at <a href="https://www.chartjs.org/docs" rel="nofollow">www.chartjs.org/docs</a>. The markdown files that build the site are available under <code>/docs</code>. Previous version documentation is available at <a href="https://www.chartjs.org/docs/latest/developers/#previous-versions" rel="nofollow">www.chartjs.org/docs/latest/developers/#previous-versions</a>.</p>
<h2><a id="user-content-contributing" class="anchor" aria-hidden="true" href="#contributing"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"></path></svg></a>Contributing</h2>
<p>Before submitting an issue or a pull request, please take a moment to look over the <a href="https://github.com/chartjs/Chart.js/blob/master/docs/developers/contributing.md">contributing guidelines</a> first. For support using Chart.js, please post questions with the <a href="https://stackoverflow.com/questions/tagged/chartjs" rel="nofollow"><code>chartjs</code> tag on Stack Overflow</a>.</p>
<h2><a id="user-content-building" class="anchor" aria-hidden="true" href="#building"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"></path></svg></a>Building</h2>
<p>Instructions on building and testing Chart.js can be found in <a href="https://github.com/chartjs/Chart.js/blob/master/docs/developers/contributing.md#building-and-testing">the documentation</a>.</p>
<h2><a id="user-content-thanks" class="anchor" aria-hidden="true" href="#thanks"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"></path></svg></a>Thanks</h2>
<ul>
<li><a href="https://browserstack.com" rel="nofollow">BrowserStack</a> for allowing our team to test on thousands of browsers.</li>
<li><a href="https://twitter.com/n8agrin" rel="nofollow">@n8agrin</a> for the Twitter handle donation.</li>
</ul>
<h2><a id="user-content-license" class="anchor" aria-hidden="true" href="#license"><svg class="octicon octicon-link" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"></path></svg></a>License</h2>
<p>Chart.js is available under the <a href="https://opensource.org/licenses/MIT" rel="nofollow">MIT license</a>.</p>
</article>
  </div>

    </div>

  

  <details class="details-reset details-overlay details-overlay-dark">
    <summary data-hotkey="l" aria-label="Jump to line"></summary>
    <details-dialog class="Box Box--overlay d-flex flex-column anim-fade-in fast linejump" aria-label="Jump to line">
      <!-- '"` --><!-- </textarea></xmp> --></option></form><form class="js-jump-to-line-form Box-body d-flex" action="" accept-charset="UTF-8" method="get"><input name="utf8" type="hidden" value="&#x2713;" />
        <input class="form-control flex-auto mr-3 linejump-input js-jump-to-line-field" type="text" placeholder="Jump to line&hellip;" aria-label="Jump to line" autofocus>
        <button type="submit" class="btn" data-close-dialog>Go</button>
</form>    </details-dialog>
  </details>



  </div>
  <div class="modal-backdrop js-touch-events"></div>
</div>

    </div>
  </div>

  </div>

        
<div class="footer container-lg px-3" role="contentinfo">
  <div class="position-relative d-flex flex-justify-between pt-6 pb-2 mt-6 f6 text-gray border-top border-gray-light ">
    <ul class="list-style-none d-flex flex-wrap ">
      <li class="mr-3">&copy; 2018 <span title="0.22270s from unicorn-6ff6f49447-bhcsm">GitHub</span>, Inc.</li>
        <li class="mr-3"><a data-ga-click="Footer, go to terms, text:terms" href="https://github.com/site/terms">Terms</a></li>
        <li class="mr-3"><a data-ga-click="Footer, go to privacy, text:privacy" href="https://github.com/site/privacy">Privacy</a></li>
        <li class="mr-3"><a href="/security" data-ga-click="Footer, go to security, text:security">Security</a></li>
        <li class="mr-3"><a href="https://githubstatus.com/" data-ga-click="Footer, go to status, text:status">Status</a></li>
        <li><a data-ga-click="Footer, go to help, text:help" href="https://help.github.com">Help</a></li>
    </ul>

    <a aria-label="Homepage" title="GitHub" class="footer-octicon mr-lg-4" href="https://github.com">
      <svg height="24" class="octicon octicon-mark-github" viewBox="0 0 16 16" version="1.1" width="24" aria-hidden="true"><path fill-rule="evenodd" d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>
</a>
   <ul class="list-style-none d-flex flex-wrap ">
        <li class="mr-3"><a data-ga-click="Footer, go to contact, text:contact" href="https://github.com/contact">Contact GitHub</a></li>
        <li class="mr-3"><a href="https://github.com/pricing" data-ga-click="Footer, go to Pricing, text:Pricing">Pricing</a></li>
      <li class="mr-3"><a href="https://developer.github.com" data-ga-click="Footer, go to api, text:api">API</a></li>
      <li class="mr-3"><a href="https://training.github.com" data-ga-click="Footer, go to training, text:training">Training</a></li>
        <li class="mr-3"><a href="https://blog.github.com" data-ga-click="Footer, go to blog, text:blog">Blog</a></li>
        <li><a data-ga-click="Footer, go to about, text:about" href="https://github.com/about">About</a></li>

    </ul>
  </div>
  <div class="d-flex flex-justify-center pb-6">
    <span class="f6 text-gray-light"></span>
  </div>
</div>



  <div id="ajax-error-message" class="ajax-error-message flash flash-error">
    <svg class="octicon octicon-alert" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8.893 1.5c-.183-.31-.52-.5-.887-.5s-.703.19-.886.5L.138 13.499a.98.98 0 0 0 0 1.001c.193.31.53.501.886.501h13.964c.367 0 .704-.19.877-.5a1.03 1.03 0 0 0 .01-1.002L8.893 1.5zm.133 11.497H6.987v-2.003h2.039v2.003zm0-3.004H6.987V5.987h2.039v4.006z"/></svg>
    <button type="button" class="flash-close js-ajax-error-dismiss" aria-label="Dismiss error">
      <svg class="octicon octicon-x" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48L7.48 8z"/></svg>
    </button>
    You can’t perform that action at this time.
  </div>


    <script crossorigin="anonymous" integrity="sha512-WnyO4VoIUwWWQOmFLjYf4UGg/c1z9VlaLN8IMuiI3uMhhl6rejyThRdLPDyePeUPW6N+38OoBMs6AkqcvWALtA==" type="application/javascript" src="https://github.githubassets.com/assets/compat-b66b5d97b4442a01f057c74b091c4368.js"></script>
    <script crossorigin="anonymous" integrity="sha512-qj1Z4g+YDVWKElb6FC42CcUWNq8P0W9aiU0CtKWjzuEMO9tb8sbbJ48dWUkmaOIe7WlLJXkI4YsUCKMxRMxT5A==" type="application/javascript" src="https://github.githubassets.com/assets/frameworks-9ee26246cce2c45ef24accded28cdabe.js"></script>
    
    <script crossorigin="anonymous" async="async" integrity="sha512-8MEu3w4BI/OqjvK4zKwQ6To5M+zmYcM3jbyhO34/c6LJQCTnXigRiALaKT2lP5CwupJrWIaz3KZ5dGVsKdbcuw==" type="application/javascript" src="https://github.githubassets.com/assets/github-a4a3b50756f2eeb89ff448862dd65628.js"></script>
    
    
    
  <div class="js-stale-session-flash stale-session-flash flash flash-warn flash-banner d-none">
    <svg class="octicon octicon-alert" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M8.893 1.5c-.183-.31-.52-.5-.887-.5s-.703.19-.886.5L.138 13.499a.98.98 0 0 0 0 1.001c.193.31.53.501.886.501h13.964c.367 0 .704-.19.877-.5a1.03 1.03 0 0 0 .01-1.002L8.893 1.5zm.133 11.497H6.987v-2.003h2.039v2.003zm0-3.004H6.987V5.987h2.039v4.006z"/></svg>
    <span class="signed-in-tab-flash">You signed in with another tab or window. <a href="">Reload</a> to refresh your session.</span>
    <span class="signed-out-tab-flash">You signed out in another tab or window. <a href="">Reload</a> to refresh your session.</span>
  </div>
  <div class="facebox" id="facebox" style="display:none;">
  <div class="facebox-popup">
    <div class="facebox-content" role="dialog" aria-labelledby="facebox-header" aria-describedby="facebox-description">
    </div>
    <button type="button" class="facebox-close js-facebox-close" aria-label="Close modal">
      <svg class="octicon octicon-x" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48L7.48 8z"/></svg>
    </button>
  </div>
</div>

  <template id="site-details-dialog">
  <details class="details-reset details-overlay details-overlay-dark lh-default text-gray-dark" open>
    <summary aria-haspopup="dialog" aria-label="Close dialog"></summary>
    <details-dialog class="Box Box--overlay d-flex flex-column anim-fade-in fast">
      <button class="Box-btn-octicon m-0 btn-octicon position-absolute right-0 top-0" type="button" aria-label="Close dialog" data-close-dialog>
        <svg class="octicon octicon-x" viewBox="0 0 12 16" version="1.1" width="12" height="16" aria-hidden="true"><path fill-rule="evenodd" d="M7.48 8l3.75 3.75-1.48 1.48L6 9.48l-3.75 3.75-1.48-1.48L4.52 8 .77 4.25l1.48-1.48L6 6.52l3.75-3.75 1.48 1.48L7.48 8z"/></svg>
      </button>
      <div class="octocat-spinner my-6 js-details-dialog-spinner"></div>
    </details-dialog>
  </details>
</template>

  <div class="Popover js-hovercard-content position-absolute" style="display: none; outline: none;" tabindex="0">
  <div class="Popover-message Popover-message--bottom-left Popover-message--large Box box-shadow-large" style="width:360px;">
  </div>
</div>

<div id="hovercard-aria-description" class="sr-only">
  Press h to open a hovercard with more details.
</div>

  <div aria-live="polite" class="js-global-screen-reader-notice sr-only"></div>

  </body>
</html>

